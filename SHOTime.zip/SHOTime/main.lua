function love.load()

    -- Set image variables
    ship = love.graphics.newImage("ship.png")
    enemy = love.graphics.newImage("enemy.png")
    bullet = love.graphics.newImage("bullet.png")
    
    -- Playable entities and unplayable entities tables
    g = {}
    p = {}

    -- Temporary entities tables
    es = {}
    bs = {} -- Player bullets

    -- Restriction tables
    limits = {}

    -- Table elements
    g.scale = 10.75
    g.w_d = {}
    g.w_d[1] = 120 * g.scale
    g.w_d[2] = 60 * g.scale
    g.sppwr = 0
    g.msc = {}
    g.msc[1] = nil  -- love.audio.newSource()

    p.pos = {}
    p.dir = {}
    p.dim = 4
    p.spd = 1 * g.scale
    p.sco = 0
    p.c_down = 0

    limits.x = (g.w_d[1] - p.dim * g.scale)
    limits.y = (g.w_d[2] - p.dim * g.scale)

    p.pos[1] = love.math.random(0, limits.x)
    p.pos[2] = love.math.random(0, limits.y)
    p.dir[1] = 1
    p.dir[2] = 0

    -- Window
    love.window.setMode(g.w_d[1], g.w_d[2])

end

function love.draw()

    love.graphics.setBackgroundColor(0.5, 0.5, 0.5)

    -- Timer and others
    love.graphics.setColor(1, 1, 1)
    love.graphics.print("Time" .. love.timer.getTime(), 0, 0)
    love.graphics.print("Super Power: " .. g.sppwr .. "/5", 0, 16)
    
    -- Enemies
    for id, e in ipairs(es) do 

        love.graphics.setColor(1, e.hp / 5, e.hp / 5)
        love.graphics.draw(enemy, e.pos[1], e.pos[2])
        
    end

    -- Bullets
    for id, b in ipairs(bs) do

        love.graphics.setColor(1, 1, 1)
        love.graphics.draw(bullet, b.pos[1], b.pos[2], 0, b.rad)

    end    

    -- Player
    love.graphics.setColor(1, 1, 1)
    love.graphics.draw(ship, p.pos[1], p.pos[2])

end

function love.update(dt) 

    -- Timer
    time = love.timer.getTime()

    -- Controls
    if love.keyboard.isDown("right") then p.pos[1] = p.pos[1] + p.spd p.dir = {1, 0} end
    if love.keyboard.isDown("left")  then p.pos[1] = p.pos[1] - p.spd p.dir = {-1 , 0} end
    if love.keyboard.isDown("down") then p.pos[2] = p.pos[2] + p.spd p.dir = {0, 1} end
    if love.keyboard.isDown("up")   then p.pos[2] = p.pos[2] - p.spd p.dir = {0, -1} end

    -- Shoot
    if love.keyboard.isDown("z") then

        p.c_down = p.c_down + 1

        -- Place in world, and set config
        if p.c_down >= 10 then

            table.insert(bs, {pos = {
                p.pos[1], p.pos[2]
            }, rad = 1, hp = 1, spd = 2, dir = {
                p.dir[1], p.dir[2]
            }, dam = 1})

            p.c_down = 0

        end

    end

    -- Super Bullet
    if love.keyboard.isDown("x") then

    -- Check super power
    if g.sppwr > 4.9 then

        -- Place in the world, and set config
        table.insert(bs, {pos = {
            p.pos[1], p.pos[2]
        }, rad = 2, hp = 10000, spd = 4, dir = {
            p.dir[1], p.dir[2]
        }, dam = 100})

        -- Resets super power
        g.sppwr = 0
    
    end

    end

    -- Restriction
    if p.pos[1] > limits.x then p.pos[1] = limits.x end
    if p.pos[2] > limits.y then p.pos[2] = limits.y end

    if p.pos[1] < 0 then p.pos[1] = 0 end
    if p.pos[2] < 0 then p.pos[2] = 0 end

    -- Spawn Enemies
    if time % 5 <= 0.1 then

        -- Place in world, and set config
        table.insert(es, {pos = {
            math.random(0, g.w_d[1]),
            math.random(0, g.w_d[2])
        }, dim = 2, spd = 1, hp = math.random(1, 5), dir = {0, 0}} )

    end
    
    -- Move Enemies
    for id, e in ipairs(es) do

        local round_X = (math.floor(e.pos[1] / g.scale) * g.scale)
        local round_Y = (math.floor(e.pos[2] / g.scale) * g.scale)
        
        local round_pX = (math.floor(p.pos[1] / g.scale) * g.scale)
        local round_pY = (math.floor(p.pos[2] / g.scale) * g.scale)

        -- Chase player
        e.pos[1] = e.pos[1] + e.dir[1] * (e.hp / e.spd)
        e.pos[2] = e.pos[2] + e.dir[2] * (e.hp / e.spd)

        if round_X > round_pX then e.dir = {-1, 0} end
        if round_X < round_pX then e.dir = {1, 0} end

        if round_Y > round_pY then e.dir = {0, -1} end
        if round_Y < round_pY then e.dir = {0, 1} end

        -- Delete (Health)
        if e.hp < 0.25 then table.remove(es, id) p.sco = p.sco + 10 end

    end

    -- Move bullets
    for id, b in ipairs(bs) do

        -- Movement
        b.pos[1] = b.pos[1] + b.dir[1] * (b.spd * g.scale)
        b.pos[2] = b.pos[2] + b.dir[2] * (b.spd * g.scale)

        -- Delete (Restriction)
        if b.pos[1] < 0 - (b.rad * g.scale) then table.remove(bs, id) end
        if b.pos[2] < 0 - (b.rad * g.scale) then table.remove(bs, id) end
        
        if b.pos[1] > g.w_d[1] then table.remove(bs, id) end
        if b.pos[2] > g.w_d[2] then table.remove(bs, id) end

        -- Delete (Health)
        if b.hp < 1 then table.remove(bs, id) end

    end

    -- Detect collision: Bullet - Enemy
    for a = 1, #es do
    for b = 1, #bs do

        if (a ~= b) then

            local dist = 
            math.abs((bs[b].pos[1] -  es[a].pos[1]) ^ 2 + (bs[b].pos[2] -  es[a].pos[2]) ^ 2)

            if dist * g.scale < ((es[a].dim ^ (2 * bs[b].rad)) * g.scale) ^ 2 then

                es[a].hp = es[a].hp - bs[b].dam
                bs[b].hp = bs[b].hp - 1

                g.sppwr = g.sppwr + 0.1

            end

            -- print(6 * (bs[a].dim ^ 2 * g.scale))

        end

    end
    end

    if g.sppwr > 5.0 then g.sppwr = 5.0 end

end